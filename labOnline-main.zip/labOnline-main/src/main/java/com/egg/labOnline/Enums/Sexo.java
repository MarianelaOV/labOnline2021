package com.egg.labOnline.Enums;

public enum Sexo { MASCULINO, FEMENINO, INDISTINTO

}
