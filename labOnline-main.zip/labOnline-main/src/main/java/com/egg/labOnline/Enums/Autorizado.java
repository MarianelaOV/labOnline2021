package com.egg.labOnline.Enums;

public enum Autorizado { Autorizado, NoAutorizado 

}
