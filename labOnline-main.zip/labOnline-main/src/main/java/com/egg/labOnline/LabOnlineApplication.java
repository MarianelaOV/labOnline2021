package com.egg.labOnline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabOnlineApplication.class, args);
	}

}
