# labOnline - Sistema de gestión de Laboratorios
<p>MVP desarrollada en Java, Spring Boot, MySQL, Thymeleaf, JavaScript y Boostrap. Deploy automático a Heroku desde GitHub.</p>

## Live Demo: www.labonline.com.ar || https://labonline.herokuapp.com/

## Login
- Admin: 22222222 // Pwd: 222
- User: 11111111 // Pwd: 111

## Team:
- https://github.com/Scastagnaviz
- https://github.com/GuillermoPilot
- https://github.com/JimenaCarracedo
- https://github.com/EmanuelMuises95
- https://github.com/rommina

## Curso: Java Full Stack. https://eggeducacion.com/
